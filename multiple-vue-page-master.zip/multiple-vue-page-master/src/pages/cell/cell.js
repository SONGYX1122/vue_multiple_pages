import Vue from 'Vue'
import cell from './cell.vue'

/* eslint-disable no-new */
new Vue({
  el: '#app',
  render: h => h(cell)
})
